// import React, { useState } from "react";
// import axios from "axios";
// import "./Shift.css";
// import { DemoContainer } from "@mui/x-date-pickers/internals/demo";
// import { AdapterDayjs } from "@mui/x-date-pickers/AdapterDayjs";
// import { LocalizationProvider } from "@mui/x-date-pickers/LocalizationProvider";
// import { TimePicker } from "@mui/x-date-pickers/TimePicker";
// import { renderTimeViewClock } from "@mui/x-date-pickers/timeViewRenderers";

// export const Shift = () => {
//   const initialDayState = {
//     ShiftStartTime: "",
//     ShiftEndTime: "",
//     LunchBreakStartTime: "",
//     LunchBreakEndTime: "",
//     TakeLunchBreakBeforeMinute: "",
//     TeaBreakStartTime: "",
//     TeaBreakEndTime: "",
//     TakeTeaBreakBeforeMinute: "",
//     HalfDayAfterTime: "",
//     HalfDayBeforeTime: "",
//     LateInCountAfterMinutes: "",
//     EarlyOutCountBeforeMinutes: "",
//     MinimumHalfDayHours: "",
//     MinimumFullDayHours: "",
//     MaximumPersonalBreak: "",
//     MaximumPunchOutTime: "",
//     MaximumPunchOutHours: "",
//   };

//   const [shiftData, setShiftData] = useState({
//     ShiftName: "",
//     HasAutoWeekOff: "",
//     WeekOffDays: "",
//     HasAlternativeWeekOff: "",
//     MaximumLateIn: "",
//     MaximumEarlyOut: "",
//     ApplyHalfDayIfLateInLimitExceeded: "",
//     RequiredReasonOFLateIn: "",
//     RequiredReasonOfEarlyOut: "",
//     MultiplePuchInOutAllow: "",
//     RequiredOutOfRangeReason: "",
//     AllowShortLeave: "",
//     ApplySandwichLeave: "",
//     TakeBreakSettings: "",
//     AddPaidLeaveOnExtraDay: "",
//     SameRulesForAllDays: false,
//     Monday: { ...initialDayState },
//     Tuesday: { ...initialDayState },
//     Wednesday: { ...initialDayState },
//     Thursday: { ...initialDayState },
//     Friday: { ...initialDayState },
//     Saturday: { ...initialDayState },
//   });

//   const handleChange = (e, day = "") => {
//     console.log(e);
//     const { name, value } = e.target;

//     // Log the selected day and corresponding ShiftStartTime or ShiftEndTime
//     if (name === "ShiftStartTime" || name === "ShiftEndTime") {
//       console.log(`${day}, ${name}: ${value}`);
//     }

//     setShiftData((prevState) => ({
//       ...prevState,
//       [day ? day : name]: value,
//     }));
//   };

//   const handleSubmit = async (e) => {
//     e.preventDefault();
//     console.log(shiftData);
//     try {
//       await axios.post("/api/editShiftTimings", shiftData);
//       alert("Shift timings updated successfully!");
//     } catch (error) {
//       console.error("Error updating shift timings:", error);
//     }
//   };

//   const handleReset = () => {
//     const resetData = {
//       ShiftName: "",
//       HasAutoWeekOff: "",
//       WeekOffDays: "",
//       HasAlternativeWeekOff: "",
//       MaximumLateIn: "",
//       MaximumEarlyOut: "",
//       ApplyHalfDayIfLateInLimitExceeded: "",
//       RequiredReasonOFLateIn: "",
//       RequiredReasonOfEarlyOut: "",
//       MultiplePuchInOutAllow: "",
//       RequiredOutOfRangeReason: "",
//       AllowShortLeave: "",
//       ApplySandwichLeave: "",
//       TakeBreakSettings: "",
//       AddPaidLeaveOnExtraDays: "",
//       SameRulesForAllDays: false,
//       Monday: { ...initialDayState },
//       Tuesday: { ...initialDayState },
//       Wednesday: { ...initialDayState },
//       Thursday: { ...initialDayState },
//       Friday: { ...initialDayState },
//       Saturday: { ...initialDayState },
//     };
//     setShiftData(resetData);
//     window.scrollTo({ top: 0, behavior: "smooth" });
//   };

//   const validateForm = () => {
//     return shiftData.ShiftName.trim() !== "";
//   };

//   return (
//     <div className="edit-shift-timings-aaa">
//       <h2>SHIFT DETAILS</h2>
//       <form onSubmit={handleSubmit}>
//         <div className="fff-form">
//           <label>
//             SHIFT NAME * :
//             <input
//               type="text"
//               name="ShiftName"
//               value={shiftData.ShiftName}
//               onChange={handleChange}
//               required
//             />
//           </label>

//           <label>
//             HAS AUTO WEEF OFF * :
//             <input
//               type="text"
//               name="HasAutoWeekOff"
//               value={shiftData.HasAutoWeekOff}
//               onChange={handleChange}
//               required
//             />
//           </label>

//           <label>
//             WEEK OFF DAYS * :
//             <input
//               type="text"
//               name="WeekOffDays"
//               value={shiftData.WeekOffDays}
//               onChange={handleChange}
//               required
//             />
//           </label>
//           <label>
//             HAS ALTERNATIVE WEEK OFF * :
//             <input
//               type="text"
//               name="HasAlternativeWeekOff"
//               value={shiftData.HasAlternativeWeekOff}
//               onChange={handleChange}
//               required
//             />
//           </label>

//           <label>
//             MAXIMUM LATE IN * :
//             <LocalizationProvider dateAdapter={AdapterDayjs}>
//               <DemoContainer
//                 components={["TimePicker"]}
//                 sx={{ padding: "2px", marginLeft: "2px" }}
//               >
//                 <TimePicker
//                   // label="With Time Clock"
//                   viewRenderers={{
//                     hours: renderTimeViewClock,
//                     minutes: renderTimeViewClock,
//                     seconds: renderTimeViewClock,
//                   }}
//                 />
//               </DemoContainer>
//             </LocalizationProvider>
//           </label>

//           <label>
//             MAXIMUM EARLY OUT * :
//             <LocalizationProvider dateAdapter={AdapterDayjs}>
//               <DemoContainer
//                 components={["TimePicker"]}
//                 sx={{ padding: "2px", marginLeft: "2px" }}
//               >
//                 <TimePicker
//                   // label="With Time Clock"
//                   viewRenderers={{
//                     hours: renderTimeViewClock,
//                     minutes: renderTimeViewClock,
//                     seconds: renderTimeViewClock,
//                   }}
//                 />
//               </DemoContainer>
//             </LocalizationProvider>
//           </label>

//           <label>
//             APPLY HALF DAY IF LATE IN LIMIT EXCEEDED(THE PROCESS RESET AND
//             REPEAT ACCORDINGLY) * :
//             <input
//               type="text"
//               name="ApplyHalfDay"
//               value={shiftData.ApplyHalfDay}
//               onChange={handleChange}
//               required
//             />
//           </label>

//           <label>
//             REQUIRED REASON OF LATE IN * :
//             <input
//               type="text"
//               name="RequiredReasonOfLateIn"
//               value={shiftData.RequiredReasonOfLateIn}
//               onChange={handleChange}
//               required
//             />
//           </label>

//           <label>
//             REQUIRED REASON OF EARLY OUT * :
//             <input
//               type="text"
//               name="RequiredReasonOfEarlyOut"
//               value={shiftData.RequiredReasonOfEarlyOut}
//               onChange={handleChange}
//               required
//             />
//           </label>

//           <label>
//             MULTIPLE PUNCH IN/OUT ALLOW * :
//             <input
//               type="text"
//               name="MultiplePunchIn"
//               value={shiftData.MultiplePunchIn}
//               onChange={handleChange}
//               required
//             />
//           </label>

//           <label>
//             REQUIRED OUT OF RANGE REASON * :
//             <input
//               type="text"
//               name="RequiredOutOfRangeReason"
//               value={shiftData.RequiredOutOfRangeReason}
//               onChange={handleChange}
//               required
//             />
//           </label>

//           <label>
//             ALLOW SHORT LEAVE * :
//             <input
//               type="text"
//               name="AllowShortLeave"
//               value={shiftData.AllowShortLeave}
//               onChange={handleChange}
//               required
//             />
//           </label>

//           <label>
//             APPLY SANDWICH LEAVE * :
//             <input
//               type="text"
//               name="ApplySandwichLeave"
//               value={shiftData.ApplySandwichLeave}
//               onChange={handleChange}
//               required
//             />
//           </label>

//           <label>
//             TAKE BREAKS SETTING * :
//             <input
//               type="text"
//               name="TakeBreaksSetting"
//               value={shiftData.TakeBreakSetting}
//               onChange={handleChange}
//               required
//             />
//           </label>

//           <label>
//             ADD PAID LEAVE ON EXTRA DAY * :
//             <input
//               type="text"
//               name="AddPaidLeaveOnExtraDay"
//               value={shiftData.AddPaidLeaveOnExtraDay}
//               onChange={handleChange}
//               required
//             />
//           </label>

//           <label>
//             LATE IN EARLY OUT APPLY ON EXTRA DAY * :
//             <input
//               type="text"
//               name="LateInEarlyOutApplyOnExtraDay"
//               value={shiftData.LateInEarlyOutApplyOnExtraDay}
//               onChange={handleChange}
//               required
//             />
//           </label>

//           <label>
//             APPLY LEAVE ON HOLIDAY * :
//             <input
//               type="text"
//               name="ApplyLeaveOnHoliday"
//               value={shiftData.ApplyLeaveOnHoliday}
//               onChange={handleChange}
//               required
//             />
//           </label>

//           <label>
//             APPLY LEAVE ON WEEKOFF * :
//             <input
//               type="text"
//               name="ApplyLeaveOnWeekOff"
//               value={shiftData.ApplyLeaveOnWeekOff}
//               onChange={handleChange}
//               required
//             />
//           </label>
//         </div>

//         <center>
//           {" "}
//           <div className="checkbox-ccc">
//             <input
//               type="checkbox"
//               name="SameRulesForAllDays"
//               checked={shiftData.SameRulesForAllDays}
//               onChange={handleChange}
//             />
//             <h6>Same Rules for All Days</h6>
//           </div>
//         </center>
//         <div className="table1">
//           <table>
//             <tbody>
//               <tr>
//                 <td>
//                   <h6>TYPE</h6>
//                 </td>
//                 <td>
//                   <h6>MONDAY</h6>
//                 </td>
//                 <td>
//                   <h6>TUESDAY</h6>
//                 </td>
//                 <td>
//                   <h6>WEDNESDAY</h6>
//                 </td>
//                 <td>
//                   <h6>THURSDAY</h6>
//                 </td>
//                 <td>
//                   <h6>FRIDAY</h6>
//                 </td>
//                 <td>
//                   <h6>SATURDAY</h6>
//                 </td>
//               </tr>
//               {Object.keys(initialDayState).map((field, index) => (
//                 <tr key={index}>
//                   <td>{field.replace(/([A-Z])/g, " $1").trim()}</td>
//                   {[...Array(6).keys()].map((dayIndex) => (
//                     <td key={dayIndex}>
//                       {[
//                         "ShiftStartTime",
//                         "ShiftEndTime",
//                         "LunchBreakStartTime",
//                         "LunchBreakEndTime",
//                         "TakeLunchBreakBeforeMinute",
//                         "TeaBreakStartTime",
//                         "TeaBreakEndTime",
//                       ].includes(field) ? (
//                         <LocalizationProvider dateAdapter={AdapterDayjs}>
//                           <DemoContainer
//                             components={["TimePicker"]}
//                             sx={{ padding: "2px", marginLeft: "2px" }}
//                           >
//                             <TimePicker
//                               value={
//                                 shiftData[Object.keys(shiftData)[dayIndex + 1]][
//                                   field
//                                 ]
//                               }
//                               onChange={(value) =>
//                                 handleChange(
//                                   { target: { name: field, value } },
//                                   Object.keys(shiftData)[dayIndex + 1]
//                                 )
//                               }
//                               viewRenderers={{
//                                 hours: renderTimeViewClock,
//                                 minutes: renderTimeViewClock,
//                                 seconds: renderTimeViewClock,
//                               }}
//                             />
//                           </DemoContainer>
//                         </LocalizationProvider>
//                       ) : (
//                         <input
//                           type="text"
//                           name={field}
//                           value={
//                             shiftData[Object.keys(shiftData)[dayIndex + 1]][
//                               field
//                             ]
//                           }
//                           onChange={(e) =>
//                             handleChange(
//                               e,
//                               Object.keys(shiftData)[dayIndex + 1]
//                             )
//                           }
//                         />
//                       )}
//                     </td>
//                   ))}
//                 </tr>
//               ))}
//             </tbody>
//           </table>
//         </div>
//         <div className="button-bu">
//           <button
//             type="button"
//             className="update-button"
//             disabled={!validateForm()}
//             onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
//           >
//             Update
//           </button>
//           <button type="button" className="reset-button" onClick={handleReset}>
//             Reset
//           </button>
//         </div>
//       </form>
//     </div>
//   );
// };
// export default Shift;





import React, { useState, useEffect } from "react";
import axios from "axios";
import "./Shift.css";
import { DemoContainer } from "@mui/x-date-pickers/internals/demo";
import { AdapterDayjs } from "@mui/x-date-pickers/AdapterDayjs";
import { LocalizationProvider } from "@mui/x-date-pickers/LocalizationProvider";
import { TimePicker } from "@mui/x-date-pickers/TimePicker";
import { renderTimeViewClock } from "@mui/x-date-pickers/timeViewRenderers";

export const Shift = () => {
  const initialDayState = {
    ShiftStartTime: "",
    ShiftEndTime: "",
    LunchBreakStartTime: "",
    LunchBreakEndTime: "",
    TakeLunchBreakBeforeMinute: "",
    TeaBreakStartTime: "",
    TeaBreakEndTime: "",
    TakeTeaBreakBeforeMinute: "",
    HalfDayAfterTime: "",
    HalfDayBeforeTime: "",
    LateInCountAfterMinutes: "",
    EarlyOutCountBeforeMinutes: "",
    MinimumHalfDayHours: "",
    MinimumFullDayHours: "",
    MaximumPersonalBreak: "",
    MaximumPunchOutTime: "",
    MaximumPunchOutHours: "",
  };

  const [shiftData, setShiftData] = useState({
    ShiftName: "",
    HasAutoWeekOff: "",
    WeekOffDays: "",
    HasAlternativeWeekOff: "",
    MaximumLateIn: "",
    MaximumEarlyOut: "",
    ApplyHalfDayIfLateInLimitExceeded: "",
    RequiredReasonOFLateIn: "",
    RequiredReasonOfEarlyOut: "",
    MultiplePuchInOutAllow: "",
    RequiredOutOfRangeReason: "",
    AllowShortLeave: "",
    ApplySandwichLeave: "",
    TakeBreakSettings: "",
    AddPaidLeaveOnExtraDay: "",
    SameRulesForAllDays: false,
    Monday: { ...initialDayState },
    Tuesday: { ...initialDayState },
    Wednesday: { ...initialDayState },
    Thursday: { ...initialDayState },
    Friday: { ...initialDayState },
    Saturday: { ...initialDayState },
  });

  useEffect(() => {
    if (shiftData.SameRulesForAllDays) {
      setShiftData((prevState) => {
        const updatedData = { ...prevState };
        Object.keys(initialDayState).forEach((key) => {
          const firstDayValue = prevState.Monday[key];
          ["Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"].forEach(
            (day) => {
              updatedData[day][key] = firstDayValue;
            }
          );
        });
        return updatedData;
      });
    } else {
      setShiftData((prevState) => {
        const updatedData = { ...prevState };
        ["Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"].forEach(
          (day) => {
            updatedData[day] = { ...initialDayState };
          }
        );
        return updatedData;
      });
    }
  }, [shiftData.SameRulesForAllDays]);

  const handleChange = (e, day = "") => {
    const { name, value } = e.target;

    setShiftData((prevState) => {
      const updatedData = { ...prevState };

      if (day) {
        updatedData[day][name] = value;
        if (shiftData.SameRulesForAllDays) {
          [
            "Monday",
            "Tuesday",
            "Wednesday",
            "Thursday",
            "Friday",
            "Saturday",
          ].forEach((d) => {
            updatedData[d][name] = value;
          });
        }
      } else {
        updatedData[name] = value;
      }

      return updatedData;
    });
  };

  const handleTimeChange = (value, name, day) => {
    setShiftData((prevState) => {
      const updatedData = { ...prevState };
      updatedData[day][name] = value;
      if (shiftData.SameRulesForAllDays) {
        [
          "Monday",
          "Tuesday",
          "Wednesday",
          "Thursday",
          "Friday",
          "Saturday",
        ].forEach((d) => {
          updatedData[d][name] = value;
        });
      }
      return updatedData;
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    console.log(shiftData);
    try {
      await axios.post("/api/editShiftTimings", shiftData);
      alert("Shift timings updated successfully!");
    } catch (error) {
      console.error("Error updating shift timings:", error);
    }
  };

  const handleReset = () => {
    const resetData = {
      ShiftName: "",
      HasAutoWeekOff: "",
      WeekOffDays: "",
      HasAlternativeWeekOff: "",
      MaximumLateIn: "",
      MaximumEarlyOut: "",
      ApplyHalfDayIfLateInLimitExceeded: "",
      RequiredReasonOFLateIn: "",
      RequiredReasonOfEarlyOut: "",
      MultiplePuchInOutAllow: "",
      RequiredOutOfRangeReason: "",
      AllowShortLeave: "",
      ApplySandwichLeave: "",
      TakeBreakSettings: "",
      AddPaidLeaveOnExtraDay: "",
      SameRulesForAllDays: false,
      Monday: { ...initialDayState },
      Tuesday: { ...initialDayState },
      Wednesday: { ...initialDayState },
      Thursday: { ...initialDayState },
      Friday: { ...initialDayState },
      Saturday: { ...initialDayState },
    };
    setShiftData(resetData);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const validateForm = () => {
    return shiftData.ShiftName.trim() !== "";
  };

  return (
    <div className="edit-shift-timings-aaa">
      <h2>SHIFT DETAILS</h2>
      <form onSubmit={handleSubmit}>
        <div className="fff-form">
          <label>
            SHIFT NAME * :
            <input
              type="text"
              name="ShiftName"
              value={shiftData.ShiftName}
              onChange={handleChange}
              required
            />
          </label>

          <label>
            HAS AUTO WEEK OFF * :
            <input
              type="text"
              name="HasAutoWeekOff"
              value={shiftData.HasAutoWeekOff}
              onChange={handleChange}
              required
            />
          </label>

          <label>
            WEEK OFF DAYS * :
            <input
              type="text"
              name="WeekOffDays"
              value={shiftData.WeekOffDays}
              onChange={handleChange}
              required
            />
          </label>
          <label>
            HAS ALTERNATIVE WEEK OFF * :
            <input
              type="text"
              name="HasAlternativeWeekOff"
              value={shiftData.HasAlternativeWeekOff}
              onChange={handleChange}
              required
            />
          </label>

          <label>
            MAXIMUM LATE IN * :
            <LocalizationProvider dateAdapter={AdapterDayjs}>
              <DemoContainer
                components={["TimePicker"]}
                sx={{ padding: "2px", marginLeft: "2px" }}
              >
                <TimePicker
                  value={shiftData.MaximumLateIn}
                  onChange={(value) =>
                    handleChange({ target: { name: "MaximumLateIn", value } })
                  }
                  viewRenderers={{
                    hours: renderTimeViewClock,
                    minutes: renderTimeViewClock,
                    seconds: renderTimeViewClock,
                  }}
                />
              </DemoContainer>
            </LocalizationProvider>
          </label>

          <label>
            MAXIMUM EARLY OUT * :
            <LocalizationProvider dateAdapter={AdapterDayjs}>
              <DemoContainer
                components={["TimePicker"]}
                sx={{ padding: "2px", marginLeft: "2px" }}
              >
                <TimePicker
                  value={shiftData.MaximumEarlyOut}
                  onChange={(value) =>
                    handleChange({ target: { name: "MaximumEarlyOut", value } })
                  }
                  viewRenderers={{
                    hours: renderTimeViewClock,
                    minutes: renderTimeViewClock,
                    seconds: renderTimeViewClock,
                  }}
                />
              </DemoContainer>
            </LocalizationProvider>
          </label>

          <label>
            APPLY HALF DAY IF LATE IN LIMIT EXCEEDED(THE PROCESS RESET AND
            REPEAT ACCORDINGLY) * :
            <input
              type="text"
              name="ApplyHalfDayIfLateInLimitExceeded"
              value={shiftData.ApplyHalfDayIfLateInLimitExceeded}
              onChange={handleChange}
              required
            />
          </label>

          <label>
            REQUIRED REASON OF LATE IN * :
            <input
              type="text"
              name="RequiredReasonOFLateIn"
              value={shiftData.RequiredReasonOFLateIn}
              onChange={handleChange}
              required
            />
          </label>

          <label>
            REQUIRED REASON OF EARLY OUT * :
            <input
              type="text"
              name="RequiredReasonOfEarlyOut"
              value={shiftData.RequiredReasonOfEarlyOut}
              onChange={handleChange}
              required
            />
          </label>

          <label>
            MULTIPLE PUNCH IN/OUT ALLOW * :
            <input
              type="text"
              name="MultiplePuchInOutAllow"
              value={shiftData.MultiplePuchInOutAllow}
              onChange={handleChange}
              required
            />
          </label>

          <label>
            REQUIRED OUT OF RANGE REASON * :
            <input
              type="text"
              name="RequiredOutOfRangeReason"
              value={shiftData.RequiredOutOfRangeReason}
              onChange={handleChange}
              required
            />
          </label>

          <label>
            ALLOW SHORT LEAVE * :
            <input
              type="text"
              name="AllowShortLeave"
              value={shiftData.AllowShortLeave}
              onChange={handleChange}
              required
            />
          </label>

          <label>
            APPLY SANDWICH LEAVE * :
            <input
              type="text"
              name="ApplySandwichLeave"
              value={shiftData.ApplySandwichLeave}
              onChange={handleChange}
              required
            />
          </label>

          <label>
            TAKE BREAKS SETTING * :
            <input
              type="text"
              name="TakeBreakSettings"
              value={shiftData.TakeBreakSettings}
              onChange={handleChange}
              required
            />
          </label>

          <label>
            ADD PAID LEAVE ON EXTRA DAY * :
            <input
              type="text"
              name="AddPaidLeaveOnExtraDay"
              value={shiftData.AddPaidLeaveOnExtraDay}
              onChange={handleChange}
              required
            />
          </label>
        </div>

        <center>
          <div className="checkbox-ccc">
            <input
              type="checkbox"
              name="SameRulesForAllDays"
              checked={shiftData.SameRulesForAllDays}
              onChange={(e) =>
                setShiftData((prevState) => ({
                  ...prevState,
                  SameRulesForAllDays: e.target.checked,
                }))
              }
            />
            <h6>Same Rules for All Days</h6>
          </div>
        </center>
        <div className="table1">
          <table>
            <tbody>
              <tr>
                <td>
                  <h6>TYPE</h6>
                </td>
                <td>
                  <h6>MONDAY</h6>
                </td>
                <td>
                  <h6>TUESDAY</h6>
                </td>
                <td>
                  <h6>WEDNESDAY</h6>
                </td>
                <td>
                  <h6>THURSDAY</h6>
                </td>
                <td>
                  <h6>FRIDAY</h6>
                </td>
                <td>
                  <h6>SATURDAY</h6>
                </td>
              </tr>
              {Object.keys(initialDayState).map((field, index) => (
                <tr key={index}>
                  <td>{field.replace(/([A-Z])/g, " $1").trim()}</td>
                  {[
                    "Monday",
                    "Tuesday",
                    "Wednesday",
                    "Thursday",
                    "Friday",
                    "Saturday",
                  ].map((day, dayIndex) => (
                    <td key={dayIndex}>
                      {[
                        "ShiftStartTime",
                        "ShiftEndTime",
                        "LunchBreakStartTime",
                        "LunchBreakEndTime",
                        "TakeLunchBreakBeforeMinute",
                        "TeaBreakStartTime",
                        "TeaBreakEndTime",
                      ].includes(field) ? (
                        <LocalizationProvider dateAdapter={AdapterDayjs}>
                          <DemoContainer
                            components={["TimePicker"]}
                            sx={{ padding: "2px", marginLeft: "2px" }}
                          >
                            <TimePicker
                              value={shiftData[day][field]}
                              onChange={(value) =>
                                handleTimeChange(value, field, day)
                              }
                              viewRenderers={{
                                hours: renderTimeViewClock,
                                minutes: renderTimeViewClock,
                                seconds: renderTimeViewClock,
                              }}
                            />
                          </DemoContainer>
                        </LocalizationProvider>
                      ) : (
                        <input
                          type="text"
                          name={field}
                          value={shiftData[day][field]}
                          onChange={(e) => handleChange(e, day)}
                        />
                      )}
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <div className="button-bu">
          <button
            type="button"
            className="update-button"
            disabled={!validateForm()}
            onClick={handleSubmit}
          >
            Update
          </button>
          <button type="button" className="reset-button" onClick={handleReset}>
            Reset
          </button>
        </div>
      </form>
    </div>
  );
};

export default Shift;






 

// import React from "react";

// export const Shift = () => {

//   const handlesubmit = (e) => {

//    e.preventDefault();
  
//     const first=e.target.fname.value;
//     const last=e.target.lname.value;
//     console.log("Firstname : " + first, "\n", "Lastname : " + last)
//   };

//   return (
//     <>
//       <form onSubmit={handlesubmit}>
//         <input type="text" placeholder="Firstname" name="fname" />
//         <input type="text" placeholder="Lastname" name="lname" />
//         <button type="submit">
//           Submit
//         </button>
//       </form>
//     </>
//   );
// }

// export default Shift;